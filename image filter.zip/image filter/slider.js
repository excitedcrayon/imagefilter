"use strict";

(function () {
    var img = document.getElementById("image-id");
    var slider1 = document.getElementById("slider-1"),
        slider2 = document.getElementById("slider-2"),
        slider3 = document.getElementById("slider-3");
    
    var sepia = slider1.value, 
        blur = slider2.value,
        grayscale = slider3.value;
    
    slider1.addEventListener("input", function(){
        sepia = this.value;
    img.style["-webkit-filter"] = "grayscale("+this.value+"%)";
    });
    
    slider2.addEventListener("input", function(){
        blur = this.value;
    img.style["-webkit-filter"] = "blur("+this.value+"px) sepia("+sepia+"%)";
    });
    
    slider3.addEventListener("input", function(){
        blur = this.value;
    //img.style["-webkit-filter"] = "gryscale("+this.value+"px) sepia("+sepia+"%)";
    });
})();